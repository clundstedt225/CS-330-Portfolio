#include <GL/glew.h> //Include GLEW header file library
#include <GLFW/glfw3.h> //Include GLFW header file library
#include <iostream> //Include iostream for error output and debugging
#include <vector>

#include "meshes.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//Image loading library for textures
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace std;

/*
Connor Lundstedt
SNHU CS-330
Final Project: Desktop Scene
*/

// Variables for window width and height
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;

glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

float deltaTime = 0.0f;	// Time between current frame and last frame
float lastFrame = 0.0f; // Time of last frame

//Global camera variables
float flySpeed = 2.5f;
float lastX = 400, lastY = 300;
float yaw = 0, pitch = 0;
bool firstMouse = true;

glm::vec3 lightPos(5.0f, 8.0f, 0.0f);

// Shader program
GLuint gProgramId;

float wX = 0, wY = 0, wZ = 0;

//Texture ID's
unsigned int woodTexture, whiteMug, bluePlastic, cardDeck, noteBook;

// Vertex Shader Program Source Code
const char* vertexShaderSource = "#version 440 core\n"
"layout (location = 0) in vec3 aPos;\n"
"layout (location = 1) in vec4 colorFromVBO;\n"
"layout (location = 2) in vec2 aTexCoord;\n"
"layout (location = 3) in vec3 aNormal;\n"
"out vec4 colorFromVS;\n"
"out vec2 TexCoord;\n"
"out vec3 FragPos;\n"
"out vec3 Normal;\n"
"uniform mat4 model;\n"
"uniform mat4 view;\n"
"uniform mat4 projection;\n"
"void main()\n"
"{\n"
"   gl_Position = projection * view *  model * vec4(aPos.x, aPos.y, aPos.z, 1.0);\n"
"   colorFromVS = colorFromVBO;\n"
"   TexCoord = aTexCoord;\n"
"   Normal = aNormal;\n"
"   FragPos = vec3(model * vec4(aPos, 1.0));\n"
"}\n\0";

// Fragment Shader Program Source Code
const char* fragmentShaderSource = "#version 440 core\n"
"in vec4 colorFromVS;\n"
"in vec3 Normal;\n"
"in vec2 TexCoord;\n"
"in vec3 FragPos;\n"
"out vec4 FragColor;\n"
"uniform sampler2D ourTexture;\n"
"uniform vec3 lightColor;\n"
"uniform vec3 lightPos;\n"
"void main()\n"
"{\n"
"   float ambientStrength = 0.1;\n"
"   vec3 ambient = ambientStrength * lightColor;\n" //Ambient
"   vec3 norm = normalize(Normal);\n"
"   vec3 lightDir = normalize(lightPos - FragPos);\n"
"   float diff = max(dot(norm, lightDir), 0.0);\n"
"   vec3 diffuse = diff * lightColor;\n" // Diffuse
"   vec3 sampledColor = texture(ourTexture, TexCoord).rgb;\n"
"   vec3 result = (ambient + diffuse) * sampledColor;\n"
"   FragColor = vec4(result, 1.0);\n"
"}\n\0";

// Function prototypes
void UResizeWindow(GLFWwindow* window, int width, int height); // resize OpenGL view with window via callback
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void CreateCube(Meshes::GLMesh& mesh); // Creates a new cube
void CreateCylinder(Meshes::GLMesh& mesh);
void CreateCircleMesh(Meshes::GLMesh& mesh, float radius, int segments);
void DestroyMesh(Meshes::GLMesh& mesh); // Releases the mesh data
bool CreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId); // Compiles and links shader source code to a program
void DrawMesh(Meshes::GLMesh& mesh, glm::vec3 pos, glm::vec3 scale, float rotAmount, glm::vec3 rotAxis, bool drawArrays, unsigned int texture);
void HandleCamera();
void processInput(GLFWwindow* window);
void processPlacementInput(GLFWwindow* window);
void RenderingSetup();
unsigned int CreateTexture(const char* texturePath); //Create and bind texture (returns textures ID for opengl)

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Project Milestone", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);

    //Initialize GLEW
    if (glewInit() != GLEW_OK) {
        cout << "Error initializing glew!" << endl;
    }

    //Print current version of OpenGL to console
    cout << "OpenGL Version: " << glGetString(GL_VERSION) << endl;

    glfwSetFramebufferSizeCallback(window, UResizeWindow);

    // Create the shader program by passing GLSL code for vertex and fragment shaders
    if (!CreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    glUseProgram(gProgramId); // Set the shader program to be used   

	//Init primitives helper object
	Meshes meshes;
	meshes.CreateMeshes();

    Meshes::GLMesh cylinderMesh; //Base of coffee mug
    Meshes::GLMesh circleMesh; //Top of coffee mug
    Meshes::GLMesh cubeMesh; //Notebook and card deck cubes

    //Set up the static 3D scene
    CreateCylinder(cylinderMesh);
    CreateCircleMesh(circleMesh, 0.5, 24);
    CreateCube(cubeMesh);

    RenderingSetup();
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); // hide cursor
    glfwSetCursorPosCallback(window, mouse_callback); // hookup callback
    glfwSetScrollCallback(window, scroll_callback);

    //Create and store texture ID's
    woodTexture = CreateTexture("woodTexture.jpg");
    whiteMug = CreateTexture("whiteMug.jpg");
    bluePlastic = CreateTexture("bluePlastic.jpg");
    cardDeck = CreateTexture("cardDeck.jpg");
    noteBook = CreateTexture("noteBook.jpg");

    //set initial color
    GLint viewLoc = glGetUniformLocation(gProgramId, "lightColor");
    glm::vec3  lColor(1.0, 1.0, 0.97);
    glUniform3f(viewLoc, lColor.x, lColor.y, lColor.z);

    //Send light pos once
    GLint lightLoc = glGetUniformLocation(gProgramId, "lightPos");
    glUniform3f(lightLoc, lightPos.x, lightPos.y, lightPos.z);

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        // Clear the frame and Z buffers.
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //Calulate deltatime
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        //processPlacementInput(window);
        processInput(window);
        HandleCamera();

        // -- draw objects --
        
        //Draw cylinder for base of coffee mug
        glm::vec3 pos1 = glm::vec3(0.0f, 0.0f, 0.0f);
        glm::vec3 scl1 = glm::vec3(.5f, 1.0f, .5f); //Draw cylinder for base of coffee mug
        DrawMesh(cylinderMesh, pos1, scl1, glm::radians(180.0), glm::vec3(1.0f, 0.0f, 0.0f), false, whiteMug);

        //Draw torus for handle of coffee mug
        glm::vec3 pos2 = glm::vec3(-0.45f, -0.1f, 0.0f);
        glm::vec3 scl2 = glm::vec3(.5f, .45f, .7f); //Draw cylinder for base of coffee mug
        DrawMesh(meshes.gTorusMesh, pos2, scl2, 15.0f, glm::vec3(0.0f, 1.0f, 0.0f), true, whiteMug);

        //Draw plane for tabletop of desk
        glm::vec3 pos3 = glm::vec3(-2.0f, -0.5f, 0.0f);
        glm::vec3 scl3 = glm::vec3(1.0f, 1.0f, .5f); 
        DrawMesh(meshes.gPlaneMesh, pos3, scl3, 0.01f, glm::vec3(1.0f, 0.0f, 0.0f), false, woodTexture);

        //Circle for top of mug
        glm::vec3 pos4 = glm::vec3(0.0f, 0.0f, -0.47f);
        glm::vec3 scl4 = glm::vec3(0.99f, 0.99f, 0.99f); 
        DrawMesh(circleMesh, pos4, scl4, glm::radians(90.0), glm::vec3(1.0f, 0.0f, 0.0f), false, woodTexture);

        //Cube for notebook
        glm::vec3 pos5 = glm::vec3(-2.7f, 0.1f, 2.0f);
        glm::vec3 scl5 = glm::vec3(1.0f, 1.75f, 0.2f);
        DrawMesh(cubeMesh, pos5, scl5, glm::radians(90.0), glm::vec3(1.0f, 0.0f, 0.0f), false, noteBook);

        //Cube for card deck
        glm::vec3 pos6 = glm::vec3(-4.2f, 0.1f, 1.5f);
        glm::vec3 scl6 = glm::vec3(0.6f, 1.0f, 0.15f);
        //glm::vec3 scl6 = glm::vec3(1.0f, 1.0f, 1.0f);
        DrawMesh(cubeMesh, pos6, scl6, glm::radians(90.0), glm::vec3(1.0f, 0.0f, 0.0f), false, cardDeck);

        //Draw cylinder for body of pen
        glm::vec3 pos7 = glm::vec3(-26.67, 2.51, -36.61);
        glm::vec3 scl7 = glm::vec3(.05f, 1.0f, .05f); //Draw cylinder for base of coffee mug
        DrawMesh(cylinderMesh, pos7, scl7, glm::radians(105.0), glm::vec3(1.0f, 0.0f, 1.0f), false, whiteMug);

        //Draw cone for tip of pen
        glm::vec3 pos8 = glm::vec3(-26.67, 15.03, -36.6);
        glm::vec3 scl8 = glm::vec3(.05f, 0.2f, .05f); //Draw cylinder for base of coffee mug
        DrawMesh(meshes.gConeMesh, pos8, scl8, glm::radians(105.0), glm::vec3(1.0f, 0.0f, 1.0f), true, bluePlastic);

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    // Release mesh data
    DestroyMesh(cylinderMesh);
    DestroyMesh(circleMesh);
	meshes.DestroyMeshes();

    // Directly release shader program
    glDeleteProgram(gProgramId);

    glfwTerminate();
    return 0;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Adjusts speed of camera via scroll wheel
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    flySpeed += (float)yoffset;

    //Speed limits for camera
    if (flySpeed < 1.0f)
        flySpeed = 1.0f;
    if (flySpeed > 15.0f)
        flySpeed = 15.0f;
}

// Rotates camera from mouse input
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 direction;
    direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    direction.y = sin(glm::radians(pitch));
    direction.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(direction);
}

//Updates cameras lookAt matrix
void HandleCamera() {
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");

    //Create and calculate lookAt matrix accordingly
    glm::mat4 view = glm::mat4(1.0f);
    view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

    //Send to shaders uniform value
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
}

//Takes in texure, creates, and binds it
unsigned int CreateTexture(const char* texturePath) {
    // Create and bind texture
    unsigned int texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    // set the texture wrapping/filtering options (on the currently bound texture object)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // load and generate the texture
    int width, height, nrChannels;
    unsigned char* data = stbi_load(texturePath, &width, &height, &nrChannels, 0);

    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;

        if (stbi_failure_reason())
            cout << "Reason: " << stbi_failure_reason();
    }

    stbi_image_free(data);

    return texture;
}


//Allows for visual placement of meshes using keys for placement
void processPlacementInput(GLFWwindow* window) {
    //General movement controlls
    if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS)
        wX += deltaTime * 1;
    if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
        wY += deltaTime * 1;
    if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS)
        wZ += deltaTime * 1;
    if (glfwGetKey(window, GLFW_KEY_V) == GLFW_PRESS)
        wX -= deltaTime * 1;
    if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS) // Up
        wY -= deltaTime * 1;
    if (glfwGetKey(window, GLFW_KEY_N) == GLFW_PRESS) // Down
        wZ -= deltaTime * 1;

    //Print to console for debugging
    cout << "X: " << wX << " Y: " << wY << " Z: " << wZ << endl;
}

void processInput(GLFWwindow* window)
{
    float cameraSpeed = flySpeed * deltaTime;

    //General movement controlls
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) // Up
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) // Down
        cameraPos -= cameraSpeed * cameraUp;

    //Set view as perspective
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        GLint projLoc = glGetUniformLocation(gProgramId, "projection");
        glm::mat4 projection = glm::perspective(glm::radians(45.0f), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection)); 
    }

    //Set view as orthographic
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
        GLint projLoc = glGetUniformLocation(gProgramId, "projection");
        glm::mat4 projection = glm::ortho(0.0f, 800.0f, 0.0f, 600.0f, 0.1f, 1000.0f);
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    }
}

//Rendering set-up that only needs to happen once
void RenderingSetup() {
    // Enable Z-depth.
    glEnable(GL_DEPTH_TEST);

    // Retrieves uniform locations in shader program
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    //Set projection matrix to use perspective view
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    //Send view and projection matrices to vertex shader
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
}

// Bind, transform, and render a mesh to screen this frame
void DrawMesh(Meshes::GLMesh &mesh, glm::vec3 pos, glm::vec3 scale, float rotAmount, glm::vec3 rotAxis, bool drawArrays, unsigned int texture) {

    //Bind meshes VAO and texture to use them for this draw call
    glBindVertexArray(mesh.vao);
    glBindTexture(GL_TEXTURE_2D, texture);

    //Update model matrix and send to shader
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");

    //Create identity matrix and apply transformations
    glm::mat4 model = glm::mat4(1.0f);
    model = glm::rotate(model, rotAmount, rotAxis);
    model = glm::scale(model, scale); // scale 
    model = glm::translate(model, pos); // place object


    //Send matrices to shader program
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    //Draw to screen this frame (Are we using an index buffer?)
    if (drawArrays) {
	    glDrawArrays(GL_TRIANGLES, 0, mesh.nVertices);
    } else {
        glDrawElements(GL_TRIANGLES, mesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangles
    }
}

void CreateCircleMesh(Meshes::GLMesh& circleMesh, float radius, int segments) {
    // Calculate the number of vertices and indices
    circleMesh.nVertices = segments + 1; // Additional vertex for center
    circleMesh.nIndices = segments * 3;

    // Create arrays to hold vertex data
    GLfloat* vertices = new GLfloat[circleMesh.nVertices * 2]; // x, y coordinates

    // Calculate the vertices
    vertices[0] = 0.0f; // Center of the circle
    vertices[1] = 0.0f;
    float angleIncrement = 2.0f * 3.14159265358979323846f / segments;
    for (int i = 0; i < segments; ++i)
    {
        float angle = i * angleIncrement;
        vertices[(i + 1) * 2] = radius * cos(angle);
        vertices[(i + 1) * 2 + 1] = radius * sin(angle);
    }

    // Generate vertex array object and vertex buffer objects
    glGenVertexArrays(1, &circleMesh.vao);
    glGenBuffers(2, circleMesh.vbos); // We need one buffer for vertices and one for indices

    // Bind VAO
    glBindVertexArray(circleMesh.vao);

    // Bind VBO for vertices
    glBindBuffer(GL_ARRAY_BUFFER, circleMesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * circleMesh.nVertices * 2, vertices, GL_STATIC_DRAW);

    // Specify vertex attribute pointers
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);

    // Generate indices
    GLushort* indices = new GLushort[circleMesh.nIndices];
    for (int i = 0; i < segments; ++i)
    {
        indices[i * 3] = 0;                      // Center of the circle
        indices[i * 3 + 1] = i + 1;              // Current vertex
        indices[i * 3 + 2] = (i + 1) % segments + 1; // Next vertex (wrapping around)
    }

    // Bind VBO for indices
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, circleMesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLushort) * circleMesh.nIndices, indices, GL_STATIC_DRAW);

    // Unbind VAO
    glBindVertexArray(0);

    // Clean up
    delete[] vertices;
    delete[] indices;
}

void CreateCylinder(Meshes::GLMesh &mesh) {
    const float PI = 3.14159265359f;
    const int sectors = 50; // Number of sectors (slices) in the cylinder
    const float height = 1.0f; // Height of the cylinder

    std::vector<float> vertices;
    std::vector<GLushort> indices;

    // Generate vertices for the side of the cylinder
    for (int i = 0; i <= sectors; ++i) {
        float theta = i * 2 * PI / sectors;
        float x = cos(theta);
        float z = sin(theta);

        // Calculate texture coordinates
        float s = (float)i / sectors; // s-coordinate
        float t1 = 0.0f; // t-coordinate for bottom vertex
        float t2 = 1.0f; // t-coordinate for top vertex

        // Bottom vertex
        vertices.push_back(x); // x
        vertices.push_back(-height / 2); // y
        vertices.push_back(z); // z
        vertices.push_back(x); // Normal x
        vertices.push_back(0); // Normal y
        vertices.push_back(z); // Normal z
        vertices.push_back(s); // Texture coordinate s
        vertices.push_back(t1); // Texture coordinate t

        // Top vertex
        vertices.push_back(x); // x
        vertices.push_back(height / 2); // y
        vertices.push_back(z); // z
        vertices.push_back(x); // Normal x
        vertices.push_back(0); // Normal y
        vertices.push_back(z); // Normal z
        vertices.push_back(s); // Texture coordinate s
        vertices.push_back(t2); // Texture coordinate t
    }

    // Generate indices for the cylinder
    for (int i = 0; i < sectors; ++i) {
        indices.push_back(i * 2);
        indices.push_back(i * 2 + 1);
        indices.push_back((i + 1) * 2 + 1);

        indices.push_back(i * 2);
        indices.push_back((i + 1) * 2 + 1);
        indices.push_back((i + 1) * 2);
    }

    // Generate the VAO, VBOs, and set up vertex attribute pointers
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLushort), indices.data(), GL_STATIC_DRAW);

    // Set up vertex attribute pointers
    // Position
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Normal
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Texture coordinates
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    mesh.nIndices = indices.size();
}


// Populate mesh struct with cube data
void CreateCube(Meshes::GLMesh& mesh) {
    GLfloat verts[] =
    {
        //Vertex Positions    //Colors (r,g,b,a)     //Texture Coords(s, t)   // Normals (x, y, z)
         0.5f,  0.5f, 0.5f,   1.0f, 0.0f, 0.0f, 1.0f,  1.0f, 1.0f,            0.0f, 1.0f, 0.0f, // Top-Right Vertex 0
         0.5f, -0.5f, 0.5f,   0.0f, 1.0f, 0.0f, 1.0f,  1.0f, 0.0f,            0.0f, 1.0f, 0.0f, // Bottom-Right Vertex 1
        -0.5f, -0.5f, 0.5f,   0.0f, 0.0f, 1.0f, 1.0f,  0.0f, 0.0f,            0.0f, 1.0f, 0.0f, // Bottom-Left Vertex 2
        -0.5f,  0.5f, 0.5f,   1.0f, 0.0f, 1.0f, 1.0f,  0.0f, 1.0f,            0.0f, 1.0f, 0.0f, // Top-Left Vertex 3

         0.5f, -0.5f, -0.5f,  0.5f, 0.5f, 1.0f, 1.0f,  1.0f, 0.0f,            0.0f, 1.0f, 0.0f, // 4 br  right
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.5f, 1.0f,  1.0f, 1.0f,            0.0f, 1.0f, 0.0f, //  5 tl  right
        -0.5f,  0.5f, -0.5f,  0.2f, 0.2f, 0.5f, 1.0f,  0.0f, 1.0f,            0.0f, 1.0f, 0.0f, //  6 tl  top
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 1.0f, 1.0f,  0.0f, 0.0f,            0.0f, 1.0f, 0.0f  //  7 bl back
    };

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos); //vbos is an array, so it's already a pointer/memory address, no need to pass by reference
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Creates a buffer object for the indices (Index/Element Buffer)
    GLushort indices[] = {
    0, 1, 3, // Triangle 1
    1, 2, 3, // Triangle 2
    0, 1, 4, // Triangle 3
    0, 4, 5, // Triangle 4
    0, 5, 6, // Triangle 5
    0, 3, 6, // Triangle 6
    4, 5, 6, // Triangle 7
    4, 6, 7, // Triangle 8
    2, 3, 6, // Triangle 9
    2, 6, 7, // Triangle 10
    1, 4, 7, // Triangle 11
    1, 2, 7  // Triangle 12
    };

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]); // div the number of values by the datatypes byte size
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Creates the Vertex Attribute Pointer for the screen coordinates
    const GLuint floatsPerPosition = 3; // (x, y, z) Number of coordinates per vertex
    const GLuint floatsPerColor = 4;  // (r, g, b, a)

    // The stride calculation must consider the added normals
    GLint stride = sizeof(float) * (floatsPerPosition + floatsPerColor + 2 + 3); // 2 for texture coordinates, 3 for normals

    // For the vertex attribute pointers
    glVertexAttribPointer(0, floatsPerPosition, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerPosition));
    glEnableVertexAttribArray(1);

    // Texture coordinates are at offset 3 (after position and color)
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerPosition + floatsPerColor)));
    glEnableVertexAttribArray(2);

    // Normals are at offset 5 (after position, color, and texture coordinates)
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerPosition + floatsPerColor + 2)));
    glEnableVertexAttribArray(3);
}

void DestroyMesh(Meshes::GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}

// Implements the UCreateShaders function
bool CreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program

    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}